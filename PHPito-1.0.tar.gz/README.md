# PHPito
PHP Server Manager

PHPito is a PHP server manager, written in Java.
With PHPito you can instantiate different PHP servers, setting a unique php.ini for each of them or choosing one of those in common.

## Use it
To use it you need to download the .tar.gz or .zip file, unpack its contents and run the phpito.sh file under Linux or Mac, otherwise run phpito.bat for Windows.
